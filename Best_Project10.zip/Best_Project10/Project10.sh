#!/bin/bash

sudo python3 Project10.py topology1 1 1000 10
sudo python3 Project10.py topology2 1 1000 10
exit 0
